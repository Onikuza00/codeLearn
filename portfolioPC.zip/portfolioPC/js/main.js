document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initTerminalTypewriter();
  initProjectExpand();
  initHeaderScroll();
});

function initNavigation() {
  const toggle = document.getElementById('navToggle');
  const links = document.getElementById('navLinks');

  if (!toggle || !links) return;

  toggle.addEventListener('click', () => {
    const isOpen = toggle.getAttribute('aria-expanded') === 'true';
    const nextState = String(!isOpen);
    toggle.setAttribute('aria-expanded', nextState);
    links.setAttribute('aria-expanded', nextState);
  });

  links.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      toggle.setAttribute('aria-expanded', 'false');
      links.setAttribute('aria-expanded', 'false');
    });
  });
}

function initProjectExpand() {
  const grid = document.getElementById('gridProjects');
  if (!grid) return;

  let activeInterval = null;

  function getCards() {
    return document.querySelectorAll('.project-card');
  }

  function collapseCard(expandEl, cb) {
    const isDesktop = window.innerWidth >= 1024;
    const card = expandEl?.closest('.project-card');

    if (isDesktop) {
      getCards().forEach(c => {
        c.style.cssText = '';
        c.style.display = '';
      });
    }

    if (expandEl && !isDesktop) {
      gsap.to(expandEl, {
        height: 0,
        duration: 0.3,
        ease: 'power2.in',
        onComplete: () => {
          card?.classList.remove('is-expanded');
          gsap.set(expandEl, { clearProps: 'height' });
          if (cb) cb();
        }
      });
    } else {
      card?.classList.remove('is-expanded');
      if (cb) cb();
    }
  }

  function expandCard(expandEl, card) {
    const isDesktop = window.innerWidth >= 1024;

    if (isDesktop) {
      card.style.cssText = 'width: 100% !important; flex: 0 0 auto; order: -1; transition: none !important;';
      card.classList.add('is-expanded');

      const all = Array.from(getCards());
      const idx = all.indexOf(card);
      const distances = all
        .map((c, i) => ({ card: c, dist: Math.abs(i - idx) }))
        .filter((_, i) => i !== idx)
        .sort((a, b) => a.dist - b.dist);
      const keepVisible = [card, ...distances.slice(0, 3).map(d => d.card)];
      all.forEach(c => {
        c.style.display = keepVisible.includes(c) ? '' : 'none';
      });
    } else {
      card.classList.add('is-expanded');
      if (expandEl) {
        gsap.set(expandEl, { height: 0 });
        expandEl.offsetHeight;
        gsap.to(expandEl, {
          height: expandEl.scrollHeight,
          duration: 0.4,
          ease: 'power3.out',
          onComplete: () => gsap.set(expandEl, { height: 'auto' })
        });
      }
    }
  }

  grid.addEventListener('click', (e) => {
    const card = e.target.closest('.project-card');
    if (!card) return;
    if (e.target.closest('a')) return;
    if (e.target.closest('.pagination')) return;

    const isExpanded = card.classList.contains('is-expanded');
    const expandEl = card.querySelector('.project-card__expand');

    if (activeInterval) {
      clearInterval(activeInterval);
      activeInterval = null;
    }

    if (isExpanded) {
      collapseCard(expandEl);
      return;
    }

    getCards().forEach(other => {
      if (other.classList.contains('is-expanded')) {
        collapseCard(other.querySelector('.project-card__expand'));
      }
    });

    expandCard(expandEl, card);

    const track = card.querySelector('.carousel__track');
    if (track && track.children.length > 2) {
      let step = 0;
      const total = track.children.length / 2;

      requestAnimationFrame(() => {
        activeInterval = setInterval(() => {
          step++;
          if (step >= total) {
            track.style.transition = 'none';
            track.style.transform = 'translateX(0)';
            step = 0;
            track.offsetHeight;
            track.style.transition = 'transform 0.30s ease';
          } else {
            track.style.transform = 'translateX(-' + (step * 100) + '%)';
            track.style.transition = 'transform 0.30s ease';
          }
        }, 2000);
      });
    }
  });

  document.addEventListener('click', (e) => {
    const expanded = document.querySelector('.project-card.is-expanded');
    if (!expanded) return;
    if (e.target.closest('.project-card')) return;

    if (activeInterval) {
      clearInterval(activeInterval);
      activeInterval = null;
    }

    collapseCard(expanded.querySelector('.project-card__expand'));
  });
}

function initHeaderScroll() {
  const header = document.getElementById('header');
  if (!header) return;

  const toggle = () => header.classList.toggle('header--scrolled', window.scrollY > 0);
  toggle(); // estado inicial
  window.addEventListener('scroll', toggle, { passive: true });
}

function initTerminalTypewriter() {
  const target = document.querySelector('.js-terminal-type');
  if (!target || typeof gsap === 'undefined') return;

  const messages = [
    'Junior Full-Stack Developer',
    'Building with Symfony, Vue, and GSAP',
    'Crafting interactive web experiences',
    'Modern UI & animation enthusiast',
    'DAW graduate — always learning',
    'Linux + Tmux + LazyVim daily driver',
  ];

  const tl = gsap.timeline({ repeat: -1 });

  messages.forEach((msg) => {
    tl.to(target, {
      text: msg,
      duration: 1.8,
      ease: 'none',
      delay: 0.8,
    })
      .to(target, {
        text: '',
        duration: 0.6,
        ease: 'none',
        delay: 2.5,
      });
  });
}
